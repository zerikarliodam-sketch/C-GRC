package com.example.como

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
